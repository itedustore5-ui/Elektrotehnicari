import { Router, type IRouter } from "express";
import { and, desc, eq } from "drizzle-orm";
import {
  GetDashboardResponse,
  GetScoreboardResponse,
  ListQuestionsResponse,
  SubmitAttemptBody,
  SubmitAttemptResponse,
} from "@workspace/api-zod";
import { db, quizAttempts, users } from "@workspace/db";
import { questions, type QuizQuestion } from "../data/questions";
import { requireAuth, type AuthedRequest } from "../middlewares/auth";

const router: IRouter = Router();

const percent = (score: number, total: number) => Math.round((score / Math.max(total, 1)) * 100);

// Definicije predmeta — opsezi ID-ova pitanja
const SUBJECTS = [
  { key: "rh",  label: "Рачунарски хардвер",             min: 1,   max: 50  },
  { key: "os",  label: "Оперативни системи",              min: 51,  max: 151 },
  { key: "ors", label: "Одржавање рачунарских система",   min: 152, max: 200 },
  { key: "td",  label: "Техничка документација",          min: 201, max: 250 },
];

function subjectForQuestion(id: number) {
  return SUBJECTS.find((s) => id >= s.min && id <= s.max);
}

async function attemptsForUser(userId: number) {
  return db.select().from(quizAttempts).where(eq(quizAttempts.userId, userId)).orderBy(desc(quizAttempts.createdAt));
}

function scoreAnswer(question: QuizQuestion, answer: string): boolean {
  try {
    if (question.type === "single") {
      return Number(answer) === question.correctAnswer;
    }
    if (question.type === "multi") {
      const selected = answer.split(",").map(Number).sort((a, b) => a - b);
      const expected = [...question.correctAnswers].sort((a, b) => a - b);
      return selected.length === expected.length && selected.every((v, i) => v === expected[i]);
    }
    if (question.type === "fill") {
      const correct = question.correctAnswer;
      if (Array.isArray(correct)) {
        // Вишеструки одговори — сваки мора да се поклопи
        const given = answer.split("|").map((s) => s.trim().toLowerCase());
        return correct.every((c, i) => c.trim().toLowerCase() === (given[i] ?? ""));
      }
      return answer.trim().toLowerCase() === correct.trim().toLowerCase();
    }
    if (question.type === "match") {
      const pairs = answer.split(",").map(Number);
      return (
        pairs.length === question.correctPairs.length &&
        pairs.every((v, i) => v === question.correctPairs[i])
      );
    }
    if (question.type === "order") {
      const positions = answer.split(",").map(Number);
      return (
        positions.length === question.correctOrder.length &&
        positions.every((v, i) => v === question.correctOrder[i])
      );
    }
  } catch {
    return false;
  }
  return false;
}

// Računa rezultate po predmetu za dati skup odgovora
function subjectStats(answers: { questionId: number; answer: string }[]) {
  const answerMap = new Map(answers.map((a) => [a.questionId, a.answer]));
  return SUBJECTS.map((subject) => {
    const subjectQuestions = questions.filter((q) => q.id >= subject.min && q.id <= subject.max);
    const answered = subjectQuestions.filter((q) => answerMap.has(q.id));
    const correct = answered.filter((q) => scoreAnswer(q, answerMap.get(q.id)!)).length;
    return {
      key: subject.key,
      label: subject.label,
      score: correct,
      total: subjectQuestions.length,
      percentage: answered.length > 0 ? percent(correct, subjectQuestions.length) : null,
    };
  });
}

router.get("/dashboard", requireAuth, async (req, res) => {
  const user = (req as AuthedRequest).user;
  const attempts = await attemptsForUser(user.id);
  const bestScore = attempts.reduce((best, attempt) => Math.max(best, attempt.percentage), 0);
  const lastScore = attempts[0]?.percentage ?? null;
  const locked = user.quizOnce && attempts.length > 0;

  // Rezultati po predmetu iz najboljeg pokusaja
  let subjectScores: { key: string; label: string; score: number; total: number; percentage: number | null }[] = [];
  if (attempts.length > 0) {
    const bestAttempt = attempts.reduce((best, a) => a.percentage > best.percentage ? a : best, attempts[0]);
    const savedAnswers = bestAttempt.answers as { questionId: number; answer: string }[];
    subjectScores = subjectStats(savedAnswers);
  } else {
    subjectScores = SUBJECTS.map((s) => ({
      key: s.key,
      label: s.label,
      score: 0,
      total: questions.filter((q) => q.id >= s.min && q.id <= s.max).length,
      percentage: null,
    }));
  }

  res.json({
    attemptsCount: attempts.length,
    bestScore,
    lastScore,
    canTakeQuiz: !locked,
    lockReason: locked ? "Искористили сте својједини покушај за квиз." : null,
    subjectScores,
  });
});

router.get("/questions", requireAuth, (_req, res) => {
  try {
    const mapped = questions.map((q) => ({
      ...q,
      // imageQuestion je boolean u questions.ts, Zod ocekuje string | null
      imageQuestion: q.imageQuestion ? `/images/${q.id}.jpg` : null,
    }));
    const result = ListQuestionsResponse.parse(mapped);
    res.json(result);
  } catch (err) {
    res.status(500).json({ message: "Greska pri ucitavanju pitanja", error: String(err) });
  }
});

router.post("/attempts", requireAuth, async (req, res) => {
  const user = (req as AuthedRequest).user;
  const previousAttempts = await attemptsForUser(user.id);
  if (user.quizOnce && previousAttempts.length > 0) {
    res.status(403).json({ message: "Искористили сте својједини покушај за квиз." });
    return;
  }

  const body = SubmitAttemptBody.parse(req.body);
  const answerMap = new Map(body.answers.map((a) => [a.questionId, a.answer]));

  const score = questions.reduce((total, question) => {
    const answer = answerMap.get(question.id);
    if (answer === undefined) return total;
    return total + (scoreAnswer(question, answer) ? 1 : 0);
  }, 0);
  const total = questions.length;
  const percentage = percent(score, total);
  const passed = percentage >= 60;

  const [attempt] = await db
    .insert(quizAttempts)
    .values({ userId: user.id, score, total, percentage, passed, answers: body.answers })
    .returning();

  res.json(
    SubmitAttemptResponse.parse({
      id: attempt.id,
      score: attempt.score,
      total: attempt.total,
      percentage: attempt.percentage,
      passed: attempt.passed,
      createdAt: attempt.createdAt.toISOString(),
    }),
  );
});

router.get("/scoreboard", requireAuth, async (req, res) => {
  const user = (req as AuthedRequest).user;

  if (user.role === "student") {
    const attempts = await attemptsForUser(user.id);
    const rows = [{
      rank: 1,
      username: user.username,
      fullName: user.fullName,
      bestScore: attempts.reduce((best, a) => Math.max(best, a.percentage), 0),
      attemptsCount: attempts.length,
      lastScore: attempts[0]?.percentage ?? null,
    }];
    res.json(GetScoreboardResponse.parse(rows));
    return;
  }

  const allUsers = await db.select().from(users).where(and(eq(users.active, true), eq(users.role, "student")));
  const allAttempts = await db.select().from(quizAttempts).orderBy(desc(quizAttempts.createdAt));

  const rows = allUsers
    .map((u) => {
      const userAttempts = allAttempts.filter((a) => a.userId === u.id);
      return {
        username: u.username,
        fullName: u.fullName,
        bestScore: userAttempts.reduce((best, a) => Math.max(best, a.percentage), 0),
        attemptsCount: userAttempts.length,
        lastScore: userAttempts[0]?.percentage ?? null,
      };
    })
    .sort((a, b) => b.bestScore - a.bestScore || a.fullName.localeCompare(b.fullName))
    .map((entry, index) => ({ rank: index + 1, ...entry }));

  res.json(GetScoreboardResponse.parse(rows));
});

export default router;
